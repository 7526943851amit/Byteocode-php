<?php
session_start();

function generateOTP() {
    return mt_rand(1000, 9999); 
}

if (!isset($_SESSION['phone'])) {
    echo "Phone number not found in session.";
    exit();
}

$phone = $_SESSION['phone'];

$otp = generateOTP();
$otp_timestamp = time();

$sid = "AC7bdddae350379b7d39f5c9016792e295";
$token = "143ac436b4a6d3f3c0d839734aaa36df";
$twilio_number = '+16065190922'; 

$client = new Twilio\Rest\Client($sid, $token);
$message = $client->messages->create(
    '+91' . $phone,
    array(
        'from' => $twilio_number,
        'body' => 'Your OTP for registration is: ' . $otp
    )
);

$_SESSION['otp'] = $otp;
$_SESSION['otp_timestamp'] = $otp_timestamp;

echo "New OTP sent successfully.";
?>
