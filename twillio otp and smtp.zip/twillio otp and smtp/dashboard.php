<?php
session_start();
if (isset($_SESSION['login'])) {
    echo "<h1 style='text-align:center;margin-top:20px;'>Welcome to dashboard</h1>";    
} else {
    header("location: login.php");
    exit(); 
}

include 'db.php';
?>
<div class="container" style='margin-top:100px;text-align:center'>
    <a href="employees.php">Employees</a>
    <?php
    $sql = "SELECT id, company_name from companies";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      echo '<div style="margin:0 auto; max-width: 400px;">';
        echo "<table border='1' >";
        echo "<tr><th>ID</th><th> Company Name</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["id"] . "</td>
            <td><a href='company_employees.php?company_id=" . $row["id"] . "'>" . $row["company_name"] . "</a></td>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "0 results";
    }

    $conn->close();
    ?>
    
</div>

