<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("location: login.php");
    exit(); 
}

include 'db.php';

if(isset($_GET['company_id'])) {
    $company_id = $_GET['company_id'];

    $sql = "SELECT company_name FROM companies WHERE id = $company_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $company_name = $row['company_name'];
    } else {
        $company_name = "Unknown";
    }

    $sql = "SELECT * FROM employees WHERE company_id = $company_id";
    $result = $conn->query($sql);

    echo "<h1 style='text-align:center;margin-top:20px;'>Employees of $company_name</h1>";

    if ($result->num_rows > 0) {
        echo '<div style="margin:0 auto; max-width: 400px;">';
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Employee Name</th><th>Role</th><th>Timer</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["id"] . "</td><td>" . $row["employee_name"] . "</td><td>" . $row["role"] . "</td>";

            echo "<td><label class='switch'><input type='checkbox' class='toggleTimer' data-employee-id='" . $row["id"] . "'>
            <span class='slider round'></span>
            </label></td></tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "No employees found for $company_name";
    }
} else {
    echo "Company ID is not set";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<style>
    .switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
    </style>
</head>
<body>

<div id="timer">00:00:00</div>

<script>
    let timerInterval;
    let seconds = 0;
    let minutes = 0;
    let hours = 0;
    let activeEmployeeId = null;

    function startTimer() {
        timerInterval = setInterval(updateTimer, 1000);
    }

    function stopTimer() {
        clearInterval(timerInterval);
    }

    function updateTimer() {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            minutes++;
            if (minutes >= 60) {
                minutes = 0;
                hours++;
            }
        }

        const formattedTime = pad(hours) + ":" + pad(minutes) + ":" + pad(seconds);
        document.getElementById('timer').innerText = formattedTime;
    }

    function pad(value) {
        return value < 10 ? "0" + value : value;
    }

    document.querySelectorAll('.toggleTimer').forEach(item => {
        item.addEventListener('change', function() {
            activeEmployeeId = this.dataset.employeeId;
            if (this.checked) {
                startTimer();
            } else {
                stopTimer();
            }
        });
    });

   
    window.addEventListener('DOMContentLoaded', function() {
        const lastActiveTime = localStorage.getItem('lastActiveTime_' + activeEmployeeId);
        if (lastActiveTime) {
            const currentTime = new Date().getTime();
            const timeDifference = currentTime - parseInt(lastActiveTime);
            const millisecondsIn24Hours = 24 * 60 * 60 * 1000;
            if (timeDifference >= millisecondsIn24Hours) {
                localStorage.removeItem('lastActiveTime_' + activeEmployeeId);
            }
        }
    });

    window.addEventListener('beforeunload', function() {
        if (activeEmployeeId) {
            localStorage.setItem('lastActiveTime_' + activeEmployeeId, new Date().getTime().toString());
        }
    });
</script>

</body>
</html>

