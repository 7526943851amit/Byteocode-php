<?php
// otp_verification_regiter.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Email Send
require_once 'twilio-php-main/src/Twilio/autoload.php';

session_start();

$sid = "AC7bdddae350379b7d39f5c9016792e295";
$token = "143ac436b4a6d3f3c0d839734aaa36df";
$twilio_number = '+16065190922'; 


function generateOTP() {
    return mt_rand(1000, 9999); 
}

if(isset($_POST['submit'])) {
    $enteredOTP = $_POST['otp'];
    if(isset($_SESSION['otp']) && $_SESSION['otp'] == $enteredOTP) {
        $otp_timestamp = $_SESSION['otp_timestamp'];
        if (time() - $otp_timestamp <= 30) { 
            include 'db.php'; 

            $fname = $_SESSION['fname'];
            $lname = $_SESSION['lname'];
            $phone = $_SESSION['phone'];
            $email = $_SESSION['email'];
            //phn check
            $check_sql = "SELECT * FROM register WHERE phone='$phone'";
            $result = mysqli_query($conn, $check_sql);
            if (mysqli_num_rows($result) > 0) {
                header("location: otp_verification_regiter.php?eror=msg2");
                exit(); 
            }
            //phn check
            $sql = "INSERT INTO register (`First_Name`, `Last_Name`, `phone`, `email`) VALUES ('$fname', '$lname', '$phone', '$email')";

            if (mysqli_query($conn, $sql)) {
                header("location: register.php?msg=insert");
                exit();
            } else {
                echo "Something went wrong. Please try again later.";
            }
        } else {
            echo "OTP has expired. Please try again.";
        }
    } else {
        echo "Invalid OTP. Please try again.";
    }
} elseif (isset($_POST['resend'])) {
    $fname = $_SESSION['fname'];
    $phone = $_SESSION['phone'];
    $email = $_SESSION['email'];
    $otp = generateOTP();
    $otp_timestamp = time();
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_timestamp'] = $otp_timestamp;

    $client = new Twilio\Rest\Client($sid, $token);
    $message = $client->messages->create(
        '+91' . $phone,
        array(
            'from' => $twilio_number,
            'body' => 'Your OTP for registration is: ' . $otp
        )
    );

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                      
        $mail->SMTPAuth   = true;                                  
        $mail->Username   = 'kulwantbytecode25@gmail.com';                 
        $mail->Password   = 'jdfbcwdzryepsmmu';                        
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         
        $mail->Port       = 587;                                   
        $mail->setFrom('kulwantbytecode25@gmail.com');
        $mail->addAddress($email);          
        $mail->isHTML(true);                                       
        $mail->Subject = 'OTP for Registration';
        $mail->Body    = 'Your OTP for registration is: ' . $otp;
        $mail->send();
        header("location: otp_verification_regiter.php?msg=otpsend");
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    $otp_msg= "New otp Send Successfully";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
</head>
<body>
    <h2>OTP Verification</h2>
    <form action="" method="post">
        <label for="otp">Enter OTP:</label><br> 
        <input type="text" id="otp" name="otp" required><br><br>
        <input type="submit" name="submit" value="Verify OTP"><br>
      <?php
      if(isset($_GET['msg'])=="otpsend"){
        echo "new otp send succesfully";
      }
      if(isset($_GET['eror'])=="msg2"){
        echo "new otp send succesfully";
      }
      ?>

        <p id="timer"></p>
    </form>
    
    <form action="" method="post">
        <input type="submit" name="resend" value="Resend OTP">
        </form>
        
   
</body>
</html>
<script>
    

    window.onload = function() {
        var countDownDate = <?php echo ($_SESSION['otp_timestamp'] + 30) * 1000; ?>; // Convert to milliseconds
        var x = setInterval(function() {
            var now = new Date().getTime();
            var distance = countDownDate - now;
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            document.getElementById("timer").innerHTML = "Time remaining: " + seconds + "s ";
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("timer").innerHTML = "OTP Expired";
            }
        }, 1000);
    }
</script>