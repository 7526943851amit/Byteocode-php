<div class="container mt-5">
    <h1 style="text-align:center;">Assign Role</h1>
    <?php
    include 'db.php'; 

    $sql = "SELECT * FROM employees";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        ?>
        <form method="POST">
            <label for="manager">Select Manager:</label>
            <select name="manager" id="manager">
                <?php
                $sql = "SELECT id, employee_name FROM employees WHERE role = 'manager'";
                $manager_result = mysqli_query($conn, $sql);
                while ($row = mysqli_fetch_assoc($manager_result)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['employee_name'] . "</option>";
                }
                ?>
            </select>

            <label for="team_leader">Select Team Leader:</label>
            <select name="team_leader" id="team_leader">
                <?php
                $sql = "SELECT id, employee_name FROM employees WHERE role = 'team_leader'";
                $team_leader_result = mysqli_query($conn, $sql);
                while ($row = mysqli_fetch_assoc($team_leader_result)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['employee_name'] . "</option>";
                }
                ?>
            </select>

            <button type="submit" name="submit">Submit</button>
        </form>
        <?php
    } else {
        echo "No employees found.";
    }

    if (isset($_POST['submit'])) {
        $manager_id = $_POST['manager'];
        $team_leader_id = $_POST['team_leader'];

        $sql = "UPDATE employees SET manager_id = '$manager_id' WHERE id = '$team_leader_id'";
        $result_manager = mysqli_query($conn, $sql);
        
        $sql = "UPDATE employees SET tl_id = '$team_leader_id' WHERE id = '$manager_id'";
        $result_team_leader = mysqli_query($conn, $sql);
        
        if ($result_manager && $result_team_leader) {
            echo "Roles updated successfully.";
        } else {
            echo "Error updating roles: " . mysqli_error($conn);
        }
    }
    ?>
</div>
