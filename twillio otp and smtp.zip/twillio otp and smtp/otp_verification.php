<?php
session_start();

if(isset($_POST['submit'])) {
    $enteredOTP = $_POST['otp'];
    if(isset($_SESSION['otp']) && $_SESSION['otp'] == $enteredOTP) {
        $otp_timestamp = $_SESSION['otp_timestamp'];
        if (time() - $otp_timestamp <= 20) { 
            header("Location: dashboard.php");
            exit();
        } else {
            echo "OTP has expired. Please try again.";
        }
    } else {
        echo "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
</head>
<body>
    <h2>OTP Verification</h2>
    <form action="" method="post">
        <label for="otp">Enter OTP:</label><br>
        <input type="text" id="otp" name="otp" required><br><br>
        <input type="submit" name="submit" value="Verify OTP">
        <p id="timer"></p>
    </form>
</body>
</html>
<script>
        window.onload = function() {
            var countDownDate = <?php echo ($_SESSION['otp_timestamp'] + 20) * 1000; ?>; // Convert to milliseconds
            var x = setInterval(function() {
                var now = new Date().getTime();
                var distance = countDownDate - now;
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                document.getElementById("timer").innerHTML = "Time remaining: " + seconds + "s ";
                if (distance < 0) {
                    clearInterval(x);
                    document.getElementById("timer").innerHTML = "OTP Expired";
                }
            }, 1000);
        }
    </script>


