<div class="
    collection-filters__filter-group
    
  " aria-label="Filters" data-filter-group="" bis_skin_checked="1">
  <button class="collection-filters__filter-group-heading productgrid--sidebar-button productgrid--sidebar-button-active" data-filter-group-trigger="" aria-expanded="true">
    <div class="collection-filters__filter-title" bis_skin_checked="1">
      Popular Ranges
    </div>

    <div class="collection-filters__filter-icon-wrapper" tabindex="-1" bis_skin_checked="1">
      <span class="collection-filters__filter-icon">
        <svg aria-hidden="true" focusable="false" role="presentation" width="8" height="6" viewBox="0 0 8 6" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-chevron-down">
<path class="icon-chevron-down-left" d="M4 4.5L7 1.5" stroke="currentColor" stroke-width="1.25" stroke-linecap="square"></path>
<path class="icon-chevron-down-right" d="M4 4.5L1 1.5" stroke="currentColor" stroke-width="1.25" stroke-linecap="square"></path>
</svg>

      </span>
    </div>
  </button>

  
      <ul class="collection-filters__filter collection-filters__filter-list filter-group-active" data-filter-group-list="" data-accordion-content="" style="--menu-open-height: 39px;" data-accordion-state="open"><li class="
              collection-filters__filter-list-item
              
            " data-filter-open="false">
            <a class="collection-filters__filter-link" data-name="filter.p.m.custom.range" data-value="Instant Pot" data-handle="filter-Popular-Ranges-0" data-url="%2Fcollections%2Fappliances%3Ffilter.p.m.custom.range%3DInstant%2BPot" href="/collections/appliances?filter.p.m.custom.range=Instant+Pot" data-filter-input="">
              <span class="filter-icon--checkbox" data-handle="filter-Popular-Ranges-0"><svg class="checkmark " aria-hidden="true" focusable="false" role="presentation" width="14" height="14" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14" data-animation-state="unchecked">
  <path class="checkmark__check" fill="none" d="M2.5 7L5.5 10L11.5 4" data-animation-state="unchecked"></path>
  <path class="checkmark__indeterminate" fill="none" d="M2.5 7L6 7L12 7" data-animation-state="unchecked"></path>
</svg>
</span>
              <span class="collection-filters__filter-list-item-text">
                Instant Pot
                
                  (61)
                
              </span>
            </a>
          </li></ul>
    
</div>
