<?php
include 'db.php';
// email Send
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
// email Send
require_once 'twilio-php-main/src/Twilio/autoload.php';
session_start();
$sid = "AC7bdddae350379b7d39f5c9016792e295";
$token = "143ac436b4a6d3f3c0d839734aaa36df";
$twilio_number = '+16065190922'; 

if(isset($_POST['submit'])) {
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $check_sql = "SELECT * FROM register WHERE phone='$phone'";
    $result = mysqli_query($conn, $check_sql);
    if (mysqli_num_rows($result) > 0) {
        // echo "Phone number already exists. Please use a different phone number.";
        header("location: register.php?eror=numexist");
        exit(); 
    }
    $otp = generateOTP();
    $otp_timestamp = time();

    $client = new Twilio\Rest\Client($sid, $token);
    $message = $client->messages->create(
        '+91' . $phone,
        array(
            'from' => $twilio_number,
            'body' => 'Your OTP for registration is: ' . $otp
        )
    );

    $mail = new PHPMailer(true);
    try {
    
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                      
        $mail->SMTPAuth   = true;                                  
        $mail->Username   = 'kulwantbytecode25@gmail.com';                 
        $mail->Password   = 'jdfbcwdzryepsmmu';                        
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         
        $mail->Port       = 587;                                   

  
        $mail->setFrom('kulwantbytecode25@gmail.com');
        $mail->addAddress($email);          

        $mail->isHTML(true);                                       
        $mail->Subject = 'OTP for Registration';
        $mail->Body    = 'Your OTP for registration is: ' . $otp;

        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    $_SESSION['otp'] = $otp;
    $_SESSION['otp_timestamp'] = $otp_timestamp;
    $_SESSION['fname'] = $fname;
    $_SESSION['lname'] = $lname;
    $_SESSION['phone'] = $phone;
    $_SESSION['email'] = $email;

    header("Location: otp_verification_regiter.php");
    exit();
} else {
    echo "Form submission error!";
}

function generateOTP() {
    return mt_rand(1000, 9999); 
}
?>
