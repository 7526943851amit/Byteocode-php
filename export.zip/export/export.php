<?php
include 'db.php';
$dietPlanSql = "SELECT * FROM diet_plan_email";
$dietPlanResult = $conn->query($dietPlanSql);

if ($dietPlanResult->num_rows > 0) {
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="exported_data.csv"');


    $output = fopen('php://output', 'w');

    fputcsv($output, array('ID', 'Name', 'Email', 'Weight', 'Height', 'Age', 'Vegan', 'Gender', 'Goal', 'Activity_Level', 'Updates', 'CreatedDate'));

   
    while ($row = $dietPlanResult->fetch_assoc()) {
        fputcsv($output, array($row["id"],$row["Name"], $row["Email"], $row["Weight"], $row["Height"], $row["Age"], $row["Vegan"], $row["Gender"], $row["Goal"], $row["Activity_Level"], $row["Updates"], $row["CreatedDate"]));
    }


    fclose($output);
} else {
    echo "No records found in diet_plan_email table.";
}

// Close the database connection
$conn->close();
?>
