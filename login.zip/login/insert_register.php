<?php
include 'db.php';
require_once 'twilio-php-main/src/Twilio/autoload.php';
session_start();
$sid = "AC7bdddae350379b7d39f5c9016792e295";
$token = "143ac436b4a6d3f3c0d839734aaa36df";
$twilio_number = '+16065190922'; 

if(isset($_POST['submit'])) {
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $phone = $_POST['phone'];
    $pass = $_POST['pass'];


    $otp = generateOTP();


    $client = new Twilio\Rest\Client($sid, $token);
    $message = $client->messages->create(
        '+91' . $phone,
        array(
            'from' => $twilio_number,
            'body' => 'Your OTP for registration is: ' . $otp
        )
    );


    $_SESSION['otp'] = $otp;
    $_SESSION['fname'] = $fname;
    $_SESSION['lname'] = $lname;
    $_SESSION['phone'] = $phone;
    $_SESSION['pass'] = $pass;


    header("Location: otp_verification_regiter.php");
    exit();
} else {
    echo "Form submission error!";
}

function generateOTP() {
    return mt_rand(1000, 9999); 
}
?>
