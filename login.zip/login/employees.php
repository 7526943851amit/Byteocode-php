<div class="container" style='margin-top:100px;text-align:center'>
    <?php
    include 'db.php';
    $query = "SELECT employees.id as employee_id, employees.employee_name, employees.role ,companies.company_name 
              FROM employees 
              INNER JOIN companies ON employees.company_id = companies.id;";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<div style='margin:0 auto;     max-width: 400px;'>";
        echo "<table border='1'>";
        echo "<tr><th>Employee ID</th><th>Employee Name</th><th>Company Name</th><th>Role</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["employee_id"] . "</td><td>" . $row["employee_name"] . "</td><td>" . $row["company_name"] . "</td><td>" . $row["role"] . "</td></tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "No results";
    }
    $conn->close();
    ?>
</div>
