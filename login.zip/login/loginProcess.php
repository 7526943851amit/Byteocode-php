<?php
// require 'twilio-php-main\src\Twilio\autoload.php';
// use Twilio\Rest\Client;
//     $sid = "AC7bdddae350379b7d39f5c9016792e295";
//     $token = "143ac436b4a6d3f3c0d839734aaa36df";
//     $twillio_number='+16065190922';
include 'db.php';
session_start();
if(isset($_POST['submit'])) {

    $phone = $_POST['phone'];
    $_SESSION["login"] =  $phone;

    $pass = $_POST['pass'];
    $sql = "SELECT * FROM register WHERE phone='$phone' AND Password='$pass'";
    $result = mysqli_query($conn, $sql);
    if($result) {
        if(mysqli_num_rows($result) > 0) {
            header("Location: dashboard.php");
            die();
        } else {
            echo "Invalid phone or password. Please try again.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
