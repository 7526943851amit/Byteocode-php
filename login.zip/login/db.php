<?php
$url = 'localhost';
$username = 'root';
$password = '';
$database = 'amit';

$conn = new mysqli($url, $username, $password, $database);

if (!$conn) {
    die('Could not Connect My Sql: ' . mysqli_error());
}
?>